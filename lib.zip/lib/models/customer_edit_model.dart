class CustomerEditModel {
  final int id;
  String name;
  String phone;
  String address;
  double creditLimit;
  String status;
  bool sendNotification;

  CustomerEditModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.creditLimit,
    required this.status,
    required this.sendNotification,
  });

  // لاستقبال البيانات من API الـ PHP (التي تجمع البيانات من عدة جداول)
  factory CustomerEditModel.fromJson(Map<String, dynamic> json) {
    return CustomerEditModel(
      id: json['id'],
      name: json['name'] ?? "",
      phone: json['phone'] ?? "",
      address: json['address'] ?? "",
      creditLimit: double.tryParse(json['credit_limit'].toString()) ?? 0.0,
      status: json['status'] ?? "نشط",
      sendNotification: json['notify'] == 1 || json['notify'] == true,
    );
  }

  // لإرسال البيانات المحدثة للسيرفر ليقوم الـ PHP بتوزيعها على الجداول
  Map<String, dynamic> toJson() => {
    "customer_id": id,
    "name": name,
    "phone": phone,
    "address": address,
    "limit_amount": creditLimit,
    "account_status": status,
    "is_notify": sendNotification ? 1 : 0,
  };
}
