import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../controllers/merchant_controller.dart';
import 'merchant_details_view.dart';

class MerchantListView extends StatefulWidget {
  final String category;
  const MerchantListView({super.key, required this.category});

  @override
  State<MerchantListView> createState() => _MerchantListViewState();
}

class _MerchantListViewState extends State<MerchantListView> {
  final MerchantController controller = Get.find<MerchantController>();
  final box = GetStorage();
  final Color primaryColor = const Color(0xFF104A81);
  int? userId;

  @override
  void initState() {
    super.initState();
    setState(() {
      // جلب البيانات فور الدخول للشاشة بناءً على التصنيف المختار
      userId = box.read('User-id') ?? 0;
      if (userId != 0) {
        // نقوم باستدعاء الدالة لجلب المتاجر التابعة لهذا التصنيف
        controller.fetchMerchants(userId!);
      }
    });

  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl, // لضمان اتساق الواجهة العربية
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F9FB),
        appBar: AppBar(
          title: const Text("المتاجر المتاحة",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.white,
          foregroundColor: primaryColor,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, size: 20),
            onPressed: () => Get.back(),
          ),
        ),
        body: Column(
          children: [
            _buildCategoryHeader(),

            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (controller.acceptedMerchants.isEmpty) {
                  return _buildEmptyState();
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  itemCount: controller.acceptedMerchants.length,
                  itemBuilder: (context, index) {
                    var merchant = controller.acceptedMerchants[index];
                    return _buildMerchantCard(merchant);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryHeader() {
    return Container(
      width: double.infinity,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Column(
        children: [
          _getCategoryHeaderIcon(widget.category),
          const SizedBox(height: 10),
          Text(widget.category,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: primaryColor)),
          const SizedBox(height: 5),
          const Text("اختر المتجر للمتابعة", style: TextStyle(color: Colors.grey, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildMerchantCard(Map merchant) {
    box.write("User-phone", merchant['User-phone']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          radius: 25,
          backgroundColor: primaryColor.withOpacity(0.1),
          child: Text(
            (merchant['Merchant-Name'] ?? "م")[0], // أول حرف من الاسم
            style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
          ),
        ),
        title: Text(
          merchant['Merchant-Name'] ?? "اسم غير معروف",
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Row(
          children: [
            const Icon(Icons.phone, size: 14, color: Colors.grey),
            const SizedBox(width: 5),
            Text(merchant['User-phone'] ?? "", style: const TextStyle(color: Colors.grey)),
          ],
        ),
        trailing: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryColor,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(horizontal: 20),
          ),
          onPressed: () {
            Get.to(() => MerchantDetailsView(), arguments: {
              'merchantId': merchant['Merchant-id'],
              'merchantName': merchant['Merchant-Name'],
            });
          },
          child: const Text("دخول", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.store_outlined, size: 80, color: Colors.grey[200]),
          const SizedBox(height: 15),
          Text("لا توجد متاجر مفعّلة في قسم ${widget.category}",
              style: const TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _getCategoryHeaderIcon(String name) {
    IconData iconData = Icons.store_mall_directory_outlined;
    if (name.contains("بقالة")) iconData = Icons.storefront_rounded;

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: primaryColor.withOpacity(0.1), shape: BoxShape.circle),
      child: Icon(iconData, size: 50, color: primaryColor),
    );
  }
}
