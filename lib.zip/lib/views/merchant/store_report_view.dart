import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/merchant_controller.dart';
import '../../controllers/report_controller.dart';
import 'package:intl/intl.dart' hide TextDirection;
import '../../controllers/debt_controller.dart';
import '../reports/debt_pdf_generator.dart';


class StoreReportView extends StatelessWidget {
  const StoreReportView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ReportController());
    final Color primaryColor = const Color(0xFF1A4D7E);
    controller.fetchReports();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text("تقرير المتجر", style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold)),
          centerTitle: true,
          actions: [
            IconButton(icon: Icon(Icons.picture_as_pdf, color: primaryColor), onPressed: () {}),
          ],
          leading: IconButton(icon: Icon(Icons.arrow_back, color: primaryColor), onPressed: () => Get.back()),
        ),
        body: Column(
          children: [
            // قسم الفلاتر (التاريخ ونوع العملية)
            _buildFilterSection(context, controller, primaryColor),

            // رأس الجدول
            _buildTableHeader(),

            // قائمة التقارير
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) return const Center(child: CircularProgressIndicator());
                if (controller.reports.isEmpty) return const Center(child: Text("لا توجد بيانات للفترة المختارة"));

                return ListView.separated(
                  itemCount: controller.reports.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    final item = controller.reports[index];
                    return _buildReportRow(item);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterSection(context, ReportController controller, Color primaryColor) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              _buildDateTile("من تاريخ", controller.fromDate, context),
              const SizedBox(width: 10),
              _buildDateTile("الى تاريخ", controller.toDate, context),
              const SizedBox(width: 10),
              _buildFilterButton(primaryColor, controller),
            ],
          ),
          const SizedBox(height: 10),
          _buildTypeDropdown(controller),
        ],
      ),
    );
  }
  Widget _buildDateTile(String label, Rx<DateTime> dateObs, context) {
    return Expanded(
      child: InkWell(
        onTap: () async {
          DateTime? picked = await showDatePicker(
              context: context, initialDate: dateObs.value,
              firstDate: DateTime(2020), lastDate: DateTime(2100));
          if (picked != null) dateObs.value = picked;
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
          decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
          child: Column(
            children: [
              Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.calendar_month, size: 16),
                const SizedBox(width: 5),
                Obx(() => Text("${dateObs.value.year}-${dateObs.value.month.toString().padLeft(2,'0')}")),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterButton(Color color, ReportController controller) {
    return Container(
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
      child: IconButton(icon: const Icon(Icons.filter_alt, color: Colors.white), onPressed: () => controller.fetchReports()),
    );
  }

  Widget _buildTypeDropdown(ReportController controller) {
    return DropdownButtonFormField<String>(
      value: controller.selectedType.value,
      decoration: InputDecoration(
        labelText: "نوع العمليه",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 10),
      ),
      items: ["كافه التقارير", "قبض مبلغ", "دين جديد"].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: (v) => controller.selectedType.value = v!,
    );
  }

  Widget _buildTableHeader() {
    return Container(
      color: Colors.grey.shade100,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      child: const Row(
        children: [
          Expanded(flex: 2, child: Text("التاريخ", style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(flex: 2, child: Text("البيان", style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(flex: 2, child: Text("العميل", style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(flex: 1, child: Text("المبلغ", style: TextStyle(fontWeight: FontWeight.bold))),
          Icon(Icons.more_vert, color: Colors.transparent), // مساحة للأيقونة
        ],
      ),
    );
  }

  Widget _buildReportRow(Map item) {
    bool isPayment = item['type'] == 'payment';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      child: Row(
        children: [
          Expanded(flex: 2, child: Text(item['date'], style: const TextStyle(fontSize: 12))),
          Expanded(flex: 2, child: Text(item['description'] ?? "")),
          Expanded(flex: 2, child: Text(item['customer_name'] ?? "")),
          Expanded(flex: 1, child: Text(item['amount'].toString(),
              style: TextStyle(color: isPayment ? Colors.green : Colors.red, fontWeight: FontWeight.bold))),
          const Icon(Icons.more_vert, color: Colors.blue, size: 20),
        ],
      ),
    );
  }
}




class MerchantOverallReportsView extends StatefulWidget {
  const MerchantOverallReportsView({super.key});

  @override
  State<MerchantOverallReportsView> createState() => _MerchantOverallReportsViewState();
}

class _MerchantOverallReportsViewState extends State<MerchantOverallReportsView> {
  final DebtController controller = Get.find<DebtController>();
  final MerchantController controllers = Get.find<MerchantController>();

  // متغيرات الفلترة
  DateTime fromDate = DateTime.now();
  DateTime toDate = DateTime.now();
  String selectedType = "كافه التقارير";

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  void _fetchData() {
    // استدعاء دالة جلب التقارير العامة من الكنترولر
    controller.fetchMerchantOverallReports(
      fromDate: DateFormat('yyyy-MM-dd').format(fromDate),
      toDate: DateFormat('yyyy-MM-dd').format(toDate),
      type: selectedType,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text("تقرير المتجر", style: TextStyle(color: Color(0xFF1A4D7E), fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: Colors.white,
          elevation: 0.5,
          actions: [
            IconButton(icon: const Icon(Icons.picture_as_pdf, color: Colors.red), onPressed: () {
              CustomerStatementPdfGenerator.generateDetailedPdf(
                customerInfo: controllers.customerInfo, // البيانات العلوية
                transactions: controllers.allTransactions, // قائمة العمليات
              );
            }),
          ],
        ),
        body: Column(
          children: [
            _buildFilters(),
            _buildTableHeader(),
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) return const Center(child: CircularProgressIndicator());
                if (controller.overallReports.isEmpty) return const Center(child: Text("لا توجد بيانات لهذه الفترة"));

                return ListView.separated(
                  itemCount: controller.overallReports.length,
                  separatorBuilder: (context, index) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final report = controller.overallReports[index];
                    return _buildReportRow(report);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  // بناء قسم الفلاتر (التاريخ والنوع)
  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(12),
      color: Colors.grey[50],
      child: Column(
        children: [
          Row(
            children: [
              _datePickerBox("من تاريخ", fromDate, (date) => setState(() { fromDate = date; _fetchData(); })),
              const SizedBox(width: 10),
              _datePickerBox("الى تاريخ", toDate, (date) => setState(() { toDate = date; _fetchData(); })),
              const SizedBox(width: 10),
              _filterButton(),
            ],
          ),
          const SizedBox(height: 12),
          _typeDropdown(),
        ],
      ),
    );
  }

  Widget _buildTableHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      color: Colors.grey[200],
      child: const Row(
        children: [
          Expanded(flex: 2, child: Text("التاريخ", textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          Expanded(flex: 2, child: Text("البيان", textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          Expanded(flex: 2, child: Text("العميل", textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          Expanded(flex: 1, child: Text("المبلغ", textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          Expanded(flex: 1, child: Text("الاجراء", textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
        ],
      ),
    );
  }

  Widget _buildReportRow(Map report) {
    bool isDebt = report['Transaction-type'] == 'debt' || report['Transaction-type'] == 'purchase';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
      child: Row(
        children: [
          Expanded(flex: 2, child: Text(report['Transaction-Date'].toString().split(' ')[0], textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))),
          Expanded(flex: 2, child: Text(report['items_summary'] ?? report['Description'] ?? "", textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))),
          Expanded(flex: 2, child: Text(report['Customer-Name'] ?? "", textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))),
          Expanded(flex: 1, child: Text("${report['Amount']}", textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: isDebt ? Colors.green : Colors.red))),
          Expanded(flex: 1, child: IconButton(
              icon: Icon(Icons.more_vert, size: 18, color: Colors.blue[800]),
            onPressed: (){}),
          ),
        ],
      ),
    );
  }

  // أداة اختيار التاريخ
  Widget _datePickerBox(String label, DateTime date, Function(DateTime) onSelect) {
    return Expanded(
      child: InkWell(
        onTap: () async {
          DateTime? picked = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2030));
          if (picked != null) onSelect(picked);
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8), color: Colors.white),
          child: Column(
            children: [
              Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
              Text(DateFormat('yyyy-MM').format(date), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _typeDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8), color: Colors.white),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: selectedType,
          items: ["كافه التقارير", "قبض مبلغ", "دين جديد"].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
          onChanged: (val) => setState(() { selectedType = val!; _fetchData(); }),
        ),
      ),
    );
  }

  Widget _filterButton() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF1A4D7E), borderRadius: BorderRadius.circular(8)),
      child: const Icon(Icons.filter_alt_outlined, color: Colors.white, size: 20),
    );
  }

}


