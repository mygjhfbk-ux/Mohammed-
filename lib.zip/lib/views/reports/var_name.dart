import 'package:get_storage/get_storage.dart';

class VarName{
  final box = GetStorage();
}