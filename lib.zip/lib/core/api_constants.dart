///
class ApiConstants {
  // الرابط الأساسي
  static const String baseUrl = "http://192.168.194.123/merchant-customer-api/mc_api";

  /// رابط انشاء حساب
  static const String register = "$baseUrl/auth/register.php";

  /// رابط تسجيل الدخول
  static const String login = "$baseUrl/auth/login.php";

  /// رابط رمز التحقق
  static const String verifyOtp = "$baseUrl/auth/otp_handler.php";

  /// رابط اعادة تعيين كلمة المرور
  static const String forgotPassword = "$baseUrl/auth/password_handler.php?action=forgot";

  /// رابط تغيير كلمة المرور
  static const String resetPassword = "$baseUrl/auth/password_handler.php?action=reset";

  /// هذا الرابط سيعالج القبول، الرفض، وإرسال طلب جديد
  static const String respondRequest = "$baseUrl/requests/respond_request.php";

  /// رابط جلب المتاجر المقبولة للعميل
  static String getAcceptedMerchantsUrl(int userId) => "$baseUrl/requests/accepted_merchants.php?userId=$userId";

  /// رابط جلب طلبات الانضمام لعميل محدد
  static String getPendingRequestsUrl(int userId) => "$baseUrl/requests/pending_requests.php?userId=$userId";

  /// رابط جلب البيانات لواجهة العميل
  static String getDashboardUrl(int userId) => "$baseUrl/requests/dashboard_data.php?userId=$userId";

  ///رابط تفاصيل العلاقة بين العميل وبقالة محددة
  static String getMerchantDetailsUrl(int merchantId, int userId) => "$baseUrl/requests/merchant_details.php?merchantId=$merchantId&userId=$userId";

  // static String getMerchantsByTypeUrl(int userId, String type) => "$baseUrl/requests/merchants_by_type.php?userId=$userId&type=$type";

  /// 7. التقارير العامة (كشف حساب شامل)
  static String getGeneralReports(int merchantId, int userId) => "$baseUrl/reports/general_reports.php?merchantId=$merchantId&userId=$userId";

  /// 6. تقارير السداد (الأموال التي دفعها العميل)
  static String getPaymentReports(int merchantId, int userId) => "$baseUrl/transactions/payment_reports.php?merchantId=$merchantId&userId=$userId";

  /// رابط اضافة دين
  static const String addDebt = "$baseUrl/transactions/add_transaction.php";

  /// رابط تعديل دين
  static const String updateTransaction = "$baseUrl/transactions/update_transaction.php";

  /// رابط اضافة سند قبض
  static const String addPayment = "$baseUrl/transactions/add_payment.php"; // تسجيل سداد

  /// رابط جلب بيانات الواجهة الرئيسية للتاجر
  static String getDashboardStats(int merchantId) => "$baseUrl/merchants/get_dashboard_stats.php?merchantId=$merchantId";

  /// رابط لجلب العملاء المرتبطين بالتاجر
  static String getCustomerByMerchant(int merchantId) => "$baseUrl/merchants/get_my_customers.php?merchant_id=$merchantId";

  /// دمجنا جلب العملاء في دالة واحدة تدعم البحث والفلترة
  static String getMerchantCustomers(int merchantId, {String search = '', String filter = 'all'}) => "$baseUrl/merchants/get_customers.php?merchantId=$merchantId&filter=$filter&search=$search";

  /// رابط جلب جميع المحافظ على حسب التاجر
  static String getWallets(int merchantId) => "$baseUrl/merchants/wallets_manager.php?merchant_id=$merchantId";

  /// رابط اضافة محفظة
  static String addWallet() => "$baseUrl/merchants/wallets_manager.php";

  /// رابط حذف محفظة
  static String deleteWallet(int walletId) => "$baseUrl/merchants/wallets_manager.php?wallet_id=$walletId";

  /// --- الإشعارات ---
  static String getNotifications(int userId) => "$baseUrl/notifications/get_notifications.php?userId=$userId";

  ///
  static Map<String, String> getHeaders() => {
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
  };
}
