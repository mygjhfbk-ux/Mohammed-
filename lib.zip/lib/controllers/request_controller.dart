import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import '../core/api_constants.dart';

class RequestController extends GetxController {
  var isLoading = false.obs;
  final box = GetStorage();

  // قوائم الطلبات
  var incomingRequests = [].obs; // طلبات قادمة للعميل من التجار
  var outgoingRequests = [].obs; // طلبات أرسلها التاجر للعملاء

  /// 1. جلب الطلبات الخاصة بالمستخدم الحالي
  Future<void> fetchMyRequests() async {
    try {
      isLoading(true);
      int? userId = box.read('User-id');
      String? userType = box.read('User-Type');

      if (userId == null) return;

      // رابط جلب الطلبات (يجب أن يدعم السيرفر الفلترة حسب الـ userId)
      var response = await http.get(
        Uri.parse(ApiConstants.getPendingRequestsUrl(userId)),
        headers: ApiConstants.getHeaders(),
      );

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        if (data['status'] == 'success') {
          // إذا كان المستخدم عميل، نعرض له الطلبات القادمة للموافقة
          incomingRequests.assignAll(data['data']);
        }
      }
    } catch (e) {
      print("Error fetching requests: $e");
    } finally {
      isLoading(false);
    }
  }

  /// 2. [للتاجر] إرسال طلب ربط لعميل جديد برقم هاتفه
  Future<void> sendRequestToCustomer(String phone, double limit) async {
    try {
      isLoading(true);
      int? merchantId = box.read('Profile-id');

      var response = await http.post(
        Uri.parse(ApiConstants.respondRequest), // الملف المسؤول عن إنشاء الطلبات
        body: {
          'Merchant-id': merchantId.toString(),
          'Customer-phone': phone,
          'account_limit': limit.toString(),
          'Request-status': '0', // حالة "معلق" بانتظار العميل
        },
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 || response.statusCode == 201) {
        Get.snackbar("تم الإرسال", "بانتظار موافقة العميل على الربط",
            backgroundColor: Colors.blue, colorText: Colors.white);
      } else {
        Get.snackbar("تنبيه", result['message'] ?? "فشل إرسال الطلب");
      }
    } catch (e) {
      Get.snackbar("خطأ", "مشكلة في الاتصال بالسيرفر");
    } finally {
      isLoading(false);
    }
  }

  /// 3. [للعميل] الرد على طلب التاجر (قبول أو رفض)
  Future<void> respondToRequest(int requestId, String status) async {
    // status: '1' للقبول، '2' للرفض
    try {
      isLoading(true);
      var response = await http.post(
        Uri.parse(ApiConstants.respondRequest),
        body: {
          'request_id': requestId.toString(),
          'Request-status': status,
        },
      );

      if (response.statusCode == 200) {
        String msg = (status == '1') ? "تم قبول الربط بنجاح" : "تم رفض الطلب";
        Get.snackbar("تحديث", msg, backgroundColor: Colors.green, colorText: Colors.white);

        // تحديث القوائم محلياً
        fetchMyRequests();
      }
    } catch (e) {
      Get.snackbar("خطأ", "فشل تنفيذ العملية");
    } finally {
      isLoading(false);
    }
  }
}
