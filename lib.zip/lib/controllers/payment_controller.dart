import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import '../core/api_constants.dart';

class PaymentController extends GetxController {
  final TextEditingController amountController = TextEditingController();
  final TextEditingController descController = TextEditingController();
  var isLoading = false.obs;
  final box = GetStorage();

  Future<void> submitPayment(int requestId, String customerName) async {
    // جلب معرف التاجر من التخزين المحلي
    int? merchantId = box.read("Profile-id");

    if (amountController.text.isEmpty || double.tryParse(amountController.text)! <= 0) {
      Get.snackbar("تنبيه", "يرجى إدخال مبلغ سداد صحيح", backgroundColor: Colors.orange);
      return;
    }

    try {
      isLoading(true);

      final response = await http.post(
        Uri.parse("${ApiConstants.baseUrl}/transactions/add_payment.php"), // استبدله برابط الملف الذي أرسلته
        headers: ApiConstants.getHeaders(),
        body: jsonEncode({
          "request_id": requestId,
          "amount": amountController.text,
          "merchant_id": merchantId,
          "description": descController.text.isEmpty ? "سداد مبلغ نقدي" : descController.text,
        }),
      );

      final result = json.decode(response.body);

      if (response.statusCode == 200 && result['status'] == 'success') {
        Get.back(result: true); // إغلاق النافذة مع إرجاع قيمة نجاح لتحديث الشاشة الرئيسية
        Get.snackbar("تم السداد", "تم خصم المبلغ من حساب $customerName بنجاح",
            backgroundColor: Colors.green, colorText: Colors.white);
        amountController.clear();
      } else {
        Get.snackbar("خطأ", result['message'] ?? "فشلت عملية السداد", backgroundColor: Colors.red);
      }
    } catch (e) {
      Get.snackbar("خطأ تقني", "تأكد من اتصالك بالإنترنت$e", backgroundColor: Colors.red);
    } finally {
      isLoading(false);
    }
  }
}
