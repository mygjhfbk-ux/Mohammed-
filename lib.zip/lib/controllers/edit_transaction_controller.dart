import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../core/api_constants.dart'; // تأكد من المسار لديك

class EditTransactionController extends GetxController {
  var isLoading = false.obs;
  var amount = "0".obs;
  var transactionsId = 0.obs;

  // الحقول النصية للواجهة
  late TextEditingController amountController;
  late TextEditingController descriptionController;

  // قائمة الأصناف للدين التفصيلي
  var editingItems = <Map<String, dynamic>>[].obs;

  // معرفات العملية الحالية
  int? currentTransactionId;
  int? currentRequestId;

  @override
  void onInit() {
    super.onInit();
    amountController = TextEditingController();
    descriptionController = TextEditingController();
  }

  // 2. دالة حساب الإجمالي تلقائياً عند تغيير أي صنف
  void calculateTotalFromItems() {
    double total = 0.0;
    for (var item in editingItems) {
      double qty = double.tryParse(item['qty'].toString()) ?? 0.0;
      double price = double.tryParse(item['price'].toString()) ?? 0.0;
      total += (qty * price);
    }
    // تحديث حقل المبلغ في الواجهة
    amountController.text = total.toStringAsFixed(2);
    amount.value = total.toStringAsFixed(2);
  }

  /// 3. دالة الحفظ وإرسال البيانات لملف PHP
  Future<void> submitUpdate() async {
    if (amountController.text.isEmpty || double.tryParse(amountController.text) == 0) {
      Get.snackbar("تنبيه", "يرجى إدخال مبلغ صحيح", backgroundColor: Colors.orange);
      return;
    }
    try {
      isLoading(true);
      var bodyData = {
        "transaction_id": currentTransactionId,
        "amount": amount.value,
        "description": descriptionController.text,
        "items": editingItems.toList(), // سترسل كـ [] في الدين العادي
      };
      var response = await http.post(
        Uri.parse("${ApiConstants.baseUrl}/transactions/update_transaction.php"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(bodyData),
      );

      var result = json.decode(response.body);

      if (response.statusCode == 200 && result['status'] == 'success') {
        Get.back(); // إغلاق واجهة التعديل
        Get.snackbar("تم بنجاح", result['message'], backgroundColor: Colors.green, colorText: Colors.white);

        // تحديث البيانات في الكنترولر الرئيسي (التاجر) لإظهار التعديلات فوراً
        // Get.find<MerchantController>().fetchGeneralReports(merchantId, requestId);
      } else {
        Get.snackbar("خطأ", result['message'] ?? "فشل التعديل", backgroundColor: Colors.red, colorText: Colors.white);
      }
    } catch (e) {
      Get.snackbar("خطأ في الاتصال", "يرجى التحقق من الشبكة", backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      isLoading(false);
    }
  }

  @override
  void onClose() {
    amountController.dispose();
    descriptionController.dispose();
    super.onClose();
  }

  // دالة جلب البيانات من السيرفر باستخدام المعرف
  Future<void> fetchTransactionDetails(int transactionId) async {
    try {
      isLoading(true);
      // استدعاء ملف PHP لجلب تفاصيل عملية محددة
      var response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/transactions/get_transaction_info.php?id=$transactionId"),
      );

      if (response.statusCode == 200) {
        var result = json.decode(response.body);

        // تعبئة الحقول الأساسية
        transactionsId.value = result['main']['Transaction-id'];
        currentTransactionId =result['main']['Transaction-id'] ;
        amountController.text = result['main']['Amount'].toString();
        amount.value = result['main']['Amount'].toString();
        descriptionController.text = result['main']['Description'] ?? "";
        // تعبئة الأصناف التفصيلية
        editingItems.clear();
        if (result['details'] != null) {
          for (var item in result['details']) {
            editingItems.add({
              "name": item['Item-Name'],
              "qty": item['Quantity'],
              "price": item['Price'],
            });
          }
        }
      }
    } catch (e) {
      Get.snackbar("خطأ", "فشل في جلب بيانات العملية");
    } finally {
      isLoading(false);
    }
  }

}


