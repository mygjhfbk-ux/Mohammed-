import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import '../core/api_constants.dart';

class MerchantController extends GetxController {
  // حالة التحميل والقوائم
  var isLoading = false.obs;
  var pendingRequests = [].obs;    // طلبات بانتظار موافقة العميل (للتاجر) أو العكس
  var acceptedMerchants = [].obs;  // البقالات التي وافق العميل عليها
  var merchantDetails = {}.obs;    // تفاصيل مديونية بقالة محددة
  // بيانات إضافية
  var allTransactions = <dynamic>[].obs;
  var notifications = <dynamic>[].obs;
  var filteredNotifications = <dynamic>[].obs;
  var selectedFilter = "الكل".obs;
  var merchantWallets = <dynamic>[].obs;
  var paymentReports = <dynamic>[].obs;
  var customerInfo = {}.obs; // لتخزين بيانات العميل (السقف، الاسم، الهاتف)
  final box = GetStorage();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController(); // للبحث عن العميل

  /// 1. [للتاجر] إرسال طلب إضافة لعميل (بدء العملية)
  Future<void> sendAddRequest(int merchantId, String customerPhone) async {
    try {
      isLoading(true);
      var response = await http.post(
        Uri.parse(ApiConstants.respondRequest), // أو ملف مخصص لإنشاء الطلب
        body: {
          'Merchant-id': merchantId.toString(),
          'Customer-phone': customerPhone,
          'Request-status': '0', // 0 تعني طلب معلق بانتظار العميل
        },
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 || response.statusCode == 201) {
        Get.snackbar("نجاح", "تم إرسال طلب الإضافة للعميل بنجاح");
      } else {
        Get.snackbar("تنبيه", result['message'] ?? "تعذر إرسال الطلب");
      }
    } catch (e) {
      Get.snackbar("خطأ", "مشكلة في الاتصال بالسيرفر");
    } finally {
      isLoading(false);
    }
  }

  /// 2. [للعميل] قبول طلب انضمام من تاجر
  Future<void> acceptRequest(int requestId, int userId) async {
    try {
      var response = await http.post(
        Uri.parse(ApiConstants.respondRequest),
        body: {
          'request_id': requestId.toString(),
          'Request-status': '1' // 1 تعني موافقة العميل
        },
      );

      if (response.statusCode == 200) {
        Get.snackbar("نجاح", "تم قبول التعامل مع البقالة وتفعيل حسابك");
        fetchPendingRequests(userId); // تحديث قائمة الطلبات المعلقة
        fetchMerchants(userId);       // تحديث قائمة المتاجر المقبولة
      }
    } catch (e) {
      Get.snackbar("خطأ", "فشل تنفيذ العملية");
    }
  }

  /// 3. جلب المتاجر المقبولة للعميل
  void fetchMerchants(int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
          Uri.parse(ApiConstants.getAcceptedMerchantsUrl(userId)));

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        acceptedMerchants.value = result['data'];
      }
    } catch (e) {
      print("Error fetching merchants: $e");
    } finally {
      isLoading(false);
    }
  }

  /// 4. جلب طلبات الإضافة المعلقة (ليراها العميل ويوافق عليها)
  void fetchPendingRequests(int userId) async {
    try {
      var response = await http.get(
          Uri.parse(ApiConstants.getPendingRequestsUrl(userId)),
          headers: ApiConstants.getHeaders()
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        pendingRequests.value = result['data'];
      }
    } catch (e) {
      print("Error fetching pending: $e");
    }
  }

  /// 5. جلب تفاصيل المديونية لمتجر محدد
  Future<void> fetchDetails(int merchantId, int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getMerchantDetailsUrl(merchantId, userId)),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        merchantDetails.value = result['data'];
      }
    } catch (e) {
      Get.snackbar("خطأ", "فشل جلب بيانات المتجر");
    } finally {
      isLoading(false);
    }
  }

  /// 6. تقارير السداد (الأموال التي دفعها العميل)
  Future<void> fetchPaymentReports(int merchantId, int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getPaymentReports(merchantId, userId)),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        paymentReports.value = result['data'];
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading(false);
    }
  }

  /// 7. التقارير العامة (كشف حساب شامل)
  Future<void> fetchGeneralReports1(int merchantId, int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getGeneralReports(merchantId, userId)),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        // نأخذ قائمة العمليات من البيانات المتداخلة
        allTransactions.value = result['data']['transactions'] ?? [];
        // يمكننا أيضاً تحديث إجمالي الدين هنا
        merchantDetails.value['total_debt'] = result['data']['total_debt'];
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading(false);
    }
  }

  /// جلب كشف الحساب المحدث (يطابق ملف PHP الثاني المحدث)
  Future<void> fetchGeneralReports(int merchantId, int requestId) async {
    try {
      isLoading(true);

      final String url = "${ApiConstants.baseUrl}/reports/general_reports.php?merchantId=$merchantId&requestId=$requestId";

      var response = await http.get(
        Uri.parse(url),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);

      if (response.statusCode == 200 && result['status'] == 'success') {
        // 1. تحديث قائمة العمليات (بما فيها الأصناف المدمجة items_summary)
        allTransactions.value = result['transactions'] ?? [];

        // 2. تحديث بيانات العميل المعروضة في البطاقة العلوية (الاسم، السقف، الدين)
        customerInfo.value = result['customer_info'] ?? {};

      } else {
        Get.snackbar("تنبيه", result['message'] ?? "لم يتم العثور على بيانات");
      }
    } catch (e) {
      print("Error fetching reports: $e");
      Get.snackbar("خطأ", "فشل الاتصال بالسيرفر");
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteTransaction(int transactionId, int requestId) async {
    try {
      isLoading(true);
      int merchantId = box.read('Profile-id');

      var response = await http.post(
        Uri.parse("${ApiConstants.baseUrl}/transactions/delete_transaction.php"),
        headers: ApiConstants.getHeaders(),
        body: jsonEncode({
          "transaction_id": transactionId,
          "merchant_id": merchantId,
        }),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        // إعادة جلب التقارير لتحديث الواجهة فوراً
        fetchGeneralReports(merchantId, requestId);
        Get.snackbar("نجاح", "تم حذف العملية وتحديث الرصيد", backgroundColor: Colors.green, colorText: Colors.white);
      } else {
        Get.snackbar("خطأ", result['message'] ?? "فشل الحذف");
      }
    } catch (e) {
      Get.snackbar("خطأ", "مشكلة في الاتصال بالسيرفر");
    } finally {
      isLoading(false);
    }
  }

  /// 8. إدارة الإشعارات
  Future<void> fetchNotifications(int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getNotifications(userId)),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        notifications.value = result['data'];
        filterNotifications(selectedFilter.value);
      }
    } finally {
      isLoading(false);
    }
  }

  void filterNotifications(String type) {
    selectedFilter.value = type;
    if (type == "الكل") {
      filteredNotifications.assignAll(notifications);
    } else {
      filteredNotifications.assignAll(notifications.where((n) => n['type'] == type).toList());
    }
  }

  /// 9. المحافظ الإلكترونية للتاجر (للسداد)
  Future<void> fetchMerchantWallets(int merchantId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getWallets(merchantId)),
        headers: ApiConstants.getHeaders(),
      );

      var result = json.decode(response.body);
      if (response.statusCode == 200 && result['status'] == 'success') {
        merchantWallets.value = result['data'];
      }
    } catch(e) {
     print("erorr:  $e");
     isLoading(false);
    }
  }

  Future<void> fetchNotifications1(int userId) async {
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(ApiConstants.getNotifications(userId)),
        headers: ApiConstants.getHeaders(),
      );

      // فك التشفير: إذا كان السيرفر يعيد قائمة مباشرة أو مصفوفة داخل 'data'
      var result = json.decode(response.body);

      // التعديل هنا ليتوافق مع ملف PHP الذي أرسلته (الذي يعيد مصفوفة مباشرة)
      if (response.statusCode == 200) {
        notifications.value = result; // لأن ملفك يعيد المصفوفة مباشرة بدون ['data']
        filterNotifications1(selectedFilter.value);
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading(false);
    }
  }

  void filterNotifications1(String filter) {
    selectedFilter.value = filter;
    if (filter == "الكل") {
      filteredNotifications.assignAll(notifications);
    } else if (filter == "غير مقروء") {
      // التمييز بناءً على الحقل Not-isread في جدولك
      filteredNotifications.assignAll(notifications.where((n) => n['Not-isread'] == 0 || n['Not-isread'] == "0").toList());
    } else if (filter == "مقروء") {
      filteredNotifications.assignAll(notifications.where((n) => n['Not-isread'] == 1 || n['Not-isread'] == "1").toList());
    }
  }

  /// دالة لتحديث حالة الإشعار في السيرفر والواجهة
  Future<void> markAsRead(int notId) async {
    try {
      // var response = await http.post(
      //   Uri.parse(ApiConstants.updateNotificationStatus()), // ملف PHP للتحديث
      //   body: jsonEncode({"notId": notId}),
      // );
      //
      // if (response.statusCode == 200) {
      //   // تحديث محلي فوري للواجهة
      //   int index = notifications.indexWhere((n) => n['Not-id'] == notId);
      //   if (index != -1) {
      //     notifications[index]['Not-isread'] = 1;
      //     filterNotifications(selectedFilter.value); // إعادة الفلترة لتحديث اللون
      //   }
      // }
    } catch (e) {
      print("Update Error: $e");
    }
  }

  Future<void> markAllAsRead() async {
    try {
      // var response = await http.post(
      //   Uri.parse(ApiConstants.updateNotificationStatus()), // ملف PHP للتحديث
      //   body: jsonEncode({"notId": notId}),
      // );
      //
      // if (response.statusCode == 200) {
      //   // تحديث محلي فوري للواجهة
      //   int index = notifications.indexWhere((n) => n['Not-id'] == notId);
      //   if (index != -1) {
      //     notifications[index]['Not-isread'] = 1;
      //     filterNotifications(selectedFilter.value); // إعادة الفلترة لتحديث اللون
      //   }
      // }
    } catch (e) {
      print("Update Error: $e");
    }
  }

}
