import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controllers/add_customer_controller.dart';
import 'controllers/auth_controller.dart';
import 'controllers/dashboard_controller.dart';
import 'controllers/debt_controller.dart';
import 'controllers/edit_transaction_controller.dart';
import 'controllers/merchant_controller.dart';
import 'controllers/merchant_customers_controller.dart';
import 'controllers/merchant_dashboard_controller.dart';
import 'controllers/report_controller.dart';
import 'controllers/wallet_controller.dart';
import 'views/welcome_view.dart';

void main() {
  Get.put(AuthController());
  Get.put(MerchantController());
  Get.put(DashboardController());
  Get.put(WalletController());
  Get.put(MerchantDashboardController());
  Get.put(MerchantCustomersController());
  Get.put(AddCustomerController());
  Get.put(ReportController());
  Get.put(DebtController());
  Get.put(EditTransactionController());
  runApp(GetMaterialApp(
    title: 'ديوني',
    debugShowCheckedModeBanner: false,
    home: WelcomeView(),
    locale: const Locale('ar'),
  ));
}

